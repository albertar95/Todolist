alter table TransactionGroups 
add [RelatedAccountId] [uniqueidentifier] NULL